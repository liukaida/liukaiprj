﻿# -*- coding=utf-8 -*-

import logging
import json
from apps.practice.models import Question
from utils.const_def import FALSE_INT
from utils.const_err import FAIL
from utils.utils_except import BusinessException
from const import *

logger = logging.getLogger(__name__)


def api_common_test(request, testparam1):
    logger.info(testparam1)
    if testparam1.lower() != 'ok':
        raise BusinessException(FAIL)
    result = testparam1
    return result


def api_practice_create_quest(request, quest_type):
    if not quest_type:
        raise BusinessException(ERR_QUEST_TYPE)

    # 检查是否已经生成题目
    old_quest = Question.objects.filter(quest_type=quest_type, del_flag=FALSE_INT)
    if old_quest:
        raise BusinessException(ERR_QUEST_HASQUEST)

    if int(quest_type) == QUEST_TYPE_ADD100[0]:
        # 100以内加
        answer_type = ANSWER_TYPE_FILLSPACE[0]

        for x in range(0, 100):
            for y in range(0, 100):
                z = x + y
                if z <= 100:
                    answer_detail = list()
                    answer_detail.append(z)
                    answer_detail_jsonstr = json.dumps(answer_detail)

                    quest = Question()
                    quest.quest_type = quest_type
                    quest.answer_type = answer_type
                    quest.quest_title = '%s + %s' % (x, y)
                    quest.title_appendattr = ''
                    quest.quest_detail = ''
                    quest.answer_detail = answer_detail_jsonstr
                    quest.weight = 1
                    quest.save()
    elif int(quest_type) == QUEST_TYPE_SUB100[0]:
        # 100以内减
        answer_type = ANSWER_TYPE_FILLSPACE[0]

        for x in range(0, 100):
            for y in range(0, 100):
                z = x - y
                if z >= 0:
                    answer_detail = list()
                    answer_detail.append(z)
                    answer_detail_jsonstr = json.dumps(answer_detail)

                    quest = Question()
                    quest.quest_type = quest_type
                    quest.answer_type = answer_type
                    quest.quest_title = '%s - %s' % (x, y)
                    quest.title_appendattr = ''
                    quest.quest_detail = ''
                    quest.answer_detail = answer_detail_jsonstr
                    quest.weight = 1
                    quest.save()
    elif int(quest_type) == QUEST_TYPE_MUL10[0]:
        # 10以内乘
        answer_type = ANSWER_TYPE_FILLSPACE[0]

        for x in range(1, 10):
            for y in range(1, 10):
                z = x * y
                if z >= 0:
                    answer_detail = list()
                    answer_detail.append(z)
                    answer_detail_jsonstr = json.dumps(answer_detail)

                    quest = Question()
                    quest.quest_type = quest_type
                    quest.answer_type = answer_type
                    quest.quest_title = '%s X %s' % (x, y)
                    quest.title_appendattr = ''
                    quest.quest_detail = ''
                    quest.answer_detail = answer_detail_jsonstr
                    quest.weight = 1
                    quest.save()
    else:
        raise BusinessException(ERR_QUEST_TYPE)
    return 'ok'


def api_practice_list_quest(request, quest_type, num):
    result = dict()
    quest_list = list()
    # 获取列表
    if not quest_type:
        raise BusinessException(ERR_QUEST_TYPE)

    quest_type = quest_type.strip(',').split(',')

    # 检查是否已经生成题目
    old_quest = Question.objects.filter(quest_type__in=quest_type, del_flag=FALSE_INT)
    if not old_quest:
        raise BusinessException(ERR_QUEST_HASQUEST)

    quests = Question.objects.filter(quest_type__in=quest_type, del_flag=FALSE_INT).order_by('?')[:num]
    sn = 0
    for each_quest in quests:
        quest_dict = {
            'sn': sn,
            'quest_title': each_quest.quest_title,
            'answer_type': each_quest.answer_type,
            'title_appendattr': each_quest.title_appendattr,
            'quest_detail': each_quest.quest_detail,
            'answer_detail': each_quest.answer_detail,
            'weight': each_quest.weight,
        }
        quest_list.append(quest_dict)
        sn += 1

    result['quest_type'] = quest_type
    result['quest_type_name'] = get_quest_name_by_type(quest_type)
    result['quest_list'] = quest_list
    result['quest_num'] = len(quest_list)
    return result


def get_quest_name_by_type(quest_type):
    name_list = []
    # quest_type = int(quest_type)
    for each_type in QUEST_TYPE_LIST:
        if str(each_type[0]) in quest_type:
            name_list.append(each_type[1])
    return u'、'.join(name_list)


def get_quest_list_page_param(request, quest_type, num):
    # result = list()
    # params = {
    #     'id': 1,
    #     'name': 2,
    #     'testlist': [5, 6, 7],
    # }
    if not quest_type:
        raise BusinessException(ERR_QUEST_TYPE)

    quest_list = api_practice_list_quest(request, quest_type, num)
    params = {
        'quest_type_name': quest_list['quest_type_name'],
        'quest_maxnum': quest_list['quest_num'],
        'quest_list': quest_list['quest_list'],
    }

    return params
