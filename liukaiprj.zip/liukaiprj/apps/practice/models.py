# -*- coding=utf-8 -*-
from django.conf import settings
from django.db import models


class Question(models.Model):
    # 0：100以内加
    # 1：100以内减
    quest_type = models.PositiveSmallIntegerField(u'题目类型', blank=False, null=False)
    answer_type = models.PositiveSmallIntegerField(u'答案种类', choices=((1, u"单选"), (2, u"多选"), (3, u"填空")), blank=False, null=False)
    quest_title = models.TextField(u'题目', blank=True, null=True)
    title_appendattr = models.CharField(u'题目附加属性', blank=True, null=True, max_length=30)  # 预留
    quest_detail = models.TextField(u'题目详情JSON', blank=True, null=True)  # 题目选项
    answer_detail = models.TextField(u'答案详情JSON', blank=True, null=True)  # 答案
    weight = models.IntegerField(u'权重', default=1, blank=True, null=True)

    create_time = models.DateTimeField(auto_now_add=True, verbose_name=u'创建时间')
    update_time = models.DateTimeField(auto_now=True, verbose_name=u'修改时间')
    del_flag = models.IntegerField(default=0, choices=((1, u"是"), (0, u"否")), verbose_name=u'是否删除')

    class Meta:
        db_table = 'question_define'
        verbose_name_plural = u'题目定义表'
        verbose_name = u'题目定义表'
        # ordering = ['-create_time']

    def __unicode__(self):
        return 'q(%s: %s)' % (self.id, self.quest_title)
