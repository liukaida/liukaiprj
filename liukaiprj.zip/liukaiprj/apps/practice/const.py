# coding=utf-8
__author__ = 'liukai'


ERR_QUEST_TYPE = [23001, u'错误的题目类型']
ERR_QUEST_HASQUEST = [23002, u'题目已经生成，请勿重新生成题目']
ERR_QUEST_NOQUEST = [23003, u'没有找到该类型题目']

QUEST_TYPE_ADD100 = [1, u'100以内加法']
QUEST_TYPE_SUB100 = [2, u'100以内减法']
QUEST_TYPE_MUL10 = [3, u'10以内减法']
QUEST_TYPE_LIST = [QUEST_TYPE_ADD100, QUEST_TYPE_SUB100, QUEST_TYPE_MUL10]

ANSWER_TYPE_SINGLE = [1, u'单选']
ANSWER_TYPE_MULTI = [2, u'多选']
ANSWER_TYPE_FILLSPACE = [3, u'填空']