# -*- coding=utf-8 -*-

import logging

from django.contrib import auth
from django.shortcuts import render_to_response

import services
from utils.check_auth import validate
from utils.check_param import InvalidHttpParaException, getp
from utils.const_err import SUCCESS
from utils.net_helper import response_parameter_error, response_exception, response200
from utils.utils_log import log_request, log_response

logger = logging.getLogger(__name__)


@validate('GET', auth=False)
def api_practice_create_quest(request):
    """
    功能说明: 创建题目
    """
    log_request(request)
    try:
        quest_type = getp(request.GET.get('quest_type'), nullable=False, para_intro='生成题目类型')

    except InvalidHttpParaException as ihpe:
        logger.exception(ihpe)
        return response_parameter_error(ihpe)

    try:
        result = services.api_practice_create_quest(request, quest_type)
    except Exception as e:
        logger.exception(e)
        return response_exception(e)
    log_response(request, result)
    return response200({'c': SUCCESS[0], 'm': SUCCESS[1], 'd': result})


@validate('GET', auth=False)
def api_practice_list_quest(request):
    """
    功能说明: 题目列表
    """
    log_request(request)
    try:
        quest_type = getp(request.GET.get('quest_type'), nullable=False, para_intro='生成题目类型')
        num = getp(request.GET.get('num'), nullable=False, para_intro='题目数量')

    except InvalidHttpParaException as ihpe:
        logger.exception(ihpe)
        return response_parameter_error(ihpe)

    try:
        result = services.api_practice_list_quest(request, quest_type, num)
    except Exception as e:
        logger.exception(e)
        return response_exception(e)
    log_response(request, result)
    return response200({'c': SUCCESS[0], 'm': SUCCESS[1], 'd': result})


def page_practice_home(request):
    """
    功能说明: 练习题首页
    """
    return render_to_response('html/practice/home.html')


def page_practice_list_quest(request):
    """
    功能说明: 题目列表页面
    """
    log_request(request)
    try:
        quest_type = getp(request.GET.get('quest_type'), nullable=False, para_intro='生成题目类型')   # 多种类型以逗号隔开
        num = getp(request.GET.get('num'), nullable=False, para_intro='题目数量')

    except InvalidHttpParaException as ihpe:
        logger.exception(ihpe)
        return response_parameter_error(ihpe)

    try:
        params = services.get_quest_list_page_param(request, quest_type, num)
    except Exception as e:
        logger.exception(e)
        return response_exception(e)
    log_response(request, params)
    return render_to_response('html/practice/index.html', params)
